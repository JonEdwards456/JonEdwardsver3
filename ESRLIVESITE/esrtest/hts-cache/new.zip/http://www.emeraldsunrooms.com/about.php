
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>New Construction Austin Texas | Outdoor Living Austin Texas</title>

	<meta http-equiv="Content-Language" content="en-us" />

	<link rel="SHORTCUT ICON" href="favicon.ico" type="image/x-icon" />

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

    <meta name="Description" content="Emerald Sunrooms offers quality and professional home improvement services in the Austin, TX area. From building sunrooms to new construction services, we guarantee to provide energy-saving and affordable solutions for your home remodeling needs." /> 

    <meta name="Keywords" content="emerald sunrooms, sunrooms in austin texas, remodeling service austin texas, new construction austin texas, solar screens austin texas, home renovations austin texas, home remodeling austin texas, outdoor living austin texas, solarium austin texas, screen rooms austin texas" /> 

	<link href="styles/styles.css" rel="stylesheet" type="text/css" />

    <link href="styles/contact.css" rel="stylesheet" type="text/css" />

    <script type="text/javascript" src="scripts/jquery.js"></script>

    

	<script type="text/javascript" src="scripts/gen_validatorv31.js"></script>

    <script type="text/javascript" src="scripts/cufon-yui.js"></script>

	<script type="text/javascript" src="scripts/arial_400-arial_700-arial_italic_400-arial_italic_700.font.js"></script>

    <script type="text/javascript" src="scripts/javascripts.js"></script>

    

    <link rel="stylesheet" type="text/css" href="styles/gallery.css" media="screen" />

    

    
    

    

	 
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50254533-1', 'emeraldsunrooms.com');
  ga('send', 'pageview');

</script>
    </head>

<body onload="blankTargetFix();" id='inner'>



<div id="cn-wrapper">
<div id="main" class="clearfix">
	<div id="content">
    <h1>About <strong>Us</strong></h1>
    <br />
    <dl>
    <dt><img src="images/content/img1.png" alt="" /></dt>
    <dd><big>Craig &amp; Stacy Cummings</big>
    Owners</dd>
    </dl>

    <p>For over 15 years Emerald Sunrooms has been adding exceptional value to Central Texas Homes and making Homeowner's Dreams a Reality!</p>
    <br />
    <p>When you combine Quality, Long-Term Community standing, a dedicated work force and 25 years in the construction industry you get one thing... Very Satisfied Customers</p>
    <br />
    <p>Emerald Sunrooms has completed almost 5,000 home improvement projects around this great State of ours and their still counting.</p>
    <br class="clear" />
    <br />
    <p>EMERALD  SUNROOMS RECOGNIZED  AS  ONE  OF TOP  50  BEST  REMODELERS IN  US.</p>
    <p><small><img src="images/content/img2.jpg" alt="" /></small></p>
    <p><a href="images/content/pdf1.pdf" rel="external">Click Here &raquo;</a></p>
    </div>
    
        <div id="header">
    <ul>
    <li><a href="index.php" >Home<small></small></a></li>
    <li><a href="gallery.php" >Gallery<small></small></a></li>
    <li><a href="services.php" >Services<small></small></a></li>
    <li><a href="about.php"  class="active-menu">About Us<small></small></a></li>
    <li><a href="contact.php" >Contact<small></small></a></li>
    </ul>
    
    <div class="hd-left">
    <h6><small><a href="index.php"><img src="images/common/hd-logo.png" alt="" /></a></small>
    </h6>
        </div>
    </div>

  
    
        
    <br class="clear" />
    
</div>
</div>

		
    	
      <div id="ft-wrapper">
  <div id="footer">
  <div class="ft-left">
  <h6><big>Call Us (512) 452-4121</big>
  7801 N Lamar Suite C-47 Austin, TX 78752</h6>
  </div>
  
  <div class="ft-right">
  <p>Legal | Privacy Statement | Anti-Spam Policy | Terms &amp; Conditions</p>
  <p>Copyright &copy; 2013.Emerald Sunrooms. All Rights Reserved</p>
  <h5><img src="images/common/header_loglo.png" alt="" /> <span><a href="https://silverconnectwebdesign.com/website-development" rel="external">Web Design</a> Done by <a href="https://silverconnectwebdesign.com" rel="external">Silver Connect Web Design LLC</a></span></h5>
  </div>
  <br class="clear" />
  </div>
  </div>
<!--- END FOOTER -->
<noscript>
  <p class="nojavascript">Your browser does not support JavaScript. Please change your browser settings to enable Javascript.</p>
  </noscript>  
</body>
</html>