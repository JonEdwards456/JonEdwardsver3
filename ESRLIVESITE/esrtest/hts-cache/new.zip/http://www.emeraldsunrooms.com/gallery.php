
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Solarium Austin Texas | Home Remodeling Austin Texas</title>

	<meta http-equiv="Content-Language" content="en-us" />

	<link rel="SHORTCUT ICON" href="favicon.ico" type="image/x-icon" />

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

    <meta name="Description" content="Emerald Sunrooms offers quality and professional home improvement services in the Austin, TX area. From building sunrooms to new construction services, we guarantee to provide energy-saving and affordable solutions for your home remodeling needs." /> 

    <meta name="Keywords" content="emerald sunrooms, sunrooms in austin texas, remodeling service austin texas, new construction austin texas, solar screens austin texas, home renovations austin texas, home remodeling austin texas, outdoor living austin texas, solarium austin texas, screen rooms austin texas" /> 

	<link href="styles/styles.css" rel="stylesheet" type="text/css" />

    <link href="styles/contact.css" rel="stylesheet" type="text/css" />

    <script type="text/javascript" src="scripts/jquery.js"></script>

    

	<script type="text/javascript" src="scripts/gen_validatorv31.js"></script>

    <script type="text/javascript" src="scripts/cufon-yui.js"></script>

	<script type="text/javascript" src="scripts/arial_400-arial_700-arial_italic_400-arial_italic_700.font.js"></script>

    <script type="text/javascript" src="scripts/javascripts.js"></script>

    

    <link rel="stylesheet" type="text/css" href="styles/gallery.css" media="screen" />

    

    
    <link rel="stylesheet" type="text/css" href="styles/jquery.fancybox-1.3.1.css" media="screen" />

    <script type="text/javascript" src="scripts/jquery.pajinate.js"></script>

    <script type="text/javascript" src="scripts/jquery.mousewheel-3.0.2.pack.js"></script>

    <script type="text/javascript" src="scripts/jquery.fancybox-1.3.1.js"></script>

    <script type="text/javascript" src="scripts/fancybox.js"></script>

    <script type="text/javascript">

        /* Pajinate Script */

   $(document).ready(function (){

    

        /* Pajinate Script */

        $('#cat_gal1').pajinate({

            num_page_links_to_display : 3,

            items_per_page : 5	

        });

		

		$('#cat_gal2').pajinate({

            num_page_links_to_display : 3,

            items_per_page : 5			

        });

		

		$('#cat_gal3').pajinate({

            num_page_links_to_display : 3,

            items_per_page : 5			

        });

		

		$('#cat_gal4').pajinate({

            num_page_links_to_display : 3,

            items_per_page : 5			

        });

		

		$('#cat_gal5').pajinate({

            num_page_links_to_display : 3,

            items_per_page : 5			

        });

		

		$('#cat_gal6').pajinate({

            num_page_links_to_display : 5,

            items_per_page : 5			

        });

		

		$('#cat_gal7').pajinate({

            num_page_links_to_display : 5,

            items_per_page : 5			

        });

		

		$('#cat_gal8').pajinate({

            num_page_links_to_display : 5,

            items_per_page : 5			

        });

		

		$('#cat_gal9').pajinate({

            num_page_links_to_display : 5,

            items_per_page : 5			

        });

    

        

          });	

    </script>

    
    

    

	 
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50254533-1', 'emeraldsunrooms.com');
  ga('send', 'pageview');

</script>
    </head>

<body onload="blankTargetFix();" id='inner'>



<div id="cn-wrapper">
<div id="main" class="clearfix">
<div id="content">
    <h1>Gallery</h1>
    <br />
    <p>Relax! Kick Back and enjoy all the relaxation you'll start to feel in your new room addition from Emerald Sunrooms.</p>
    <br />
    <p>Whether you want a Game Room; A Garden Space; A Breezy Screen Room; A Cool, Sun-Drenched Escape; or Extra Square Footage, we have the designs and the craftsmen to bring it all to life!</p>
    <br />
    <p>So take a minute to dream and relax and see what true value really looks like.</p>
    <br />
    <p>Then give us a call for a FREE in-home estimate.</p>
    <br />
    <h3>Solariums</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal1" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/1.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/1.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/2.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/2.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/3.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/3.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/4.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/4.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/5.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/5.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/6.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/6.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/7.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/7.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/8.jpg" rel="gallery"><img alt="Solariums&nbsp;" src="images/gallery/tm/8.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
    
    <br />
    <h3>Remodeling</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal2" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/9.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/9.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/10.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/10.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/11.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/11.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/12.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/12.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/13.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/13.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/14.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/14.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/15.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/15.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/16.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/16.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/17.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/17.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/18.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/18.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/19.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/19.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/20.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/20.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/21.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/21.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/22.jpg" rel="gallery"><img alt="Remodeling&nbsp;" src="images/gallery/tm/22.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
    
    <br />
    <h3>Sunrooms</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal3" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/23.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/23.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/24.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/24.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/25.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/25.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/26.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/26.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/27.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/27.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/28.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/28.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/29.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/29.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/30.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/30.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/31.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/31.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/32.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/32.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/33.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/33.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/34.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/34.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/35.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/35.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/36.jpg" rel="gallery"><img alt="Sunrooms&nbsp;" src="images/gallery/tm/36.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/80.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/80.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/81.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/81.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/82.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/82.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/84.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/84.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/86.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/86.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/87.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/87.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/90.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/90.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/91.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/91.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/93.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/93.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/96.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/96.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
    
    <br />
    <h3>Windows &amp; Doors</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal4" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/37.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/37.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/38.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/38.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/39.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/39.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/40.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/40.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/41.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/41.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/42.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/42.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/43.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/43.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/44.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/44.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/45.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/45.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/46.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/46.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/47.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/47.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/48.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/48.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/49.jpg" rel="gallery"><img alt="Windows & Doors&nbsp;" src="images/gallery/tm/49.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
    
    <br />
    <h3>Pool Enclosures &amp; Screen Rooms</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal5" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/50.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/50.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/51.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/51.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/52.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/52.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/53.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/53.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/54.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/54.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/55.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/55.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/56.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/56.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/57.jpg" rel="gallery"><img alt="Pool Enclosures & Screen Rooms&nbsp;" src="images/gallery/tm/57.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
	
	<h3>Great Rooms Remodeling</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal6" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/75.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/75.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/76.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/76.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/98.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/98.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
	
	<h3>Kitchen Remodeling</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal7" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/59.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/59.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/72.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/72.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/73.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/73.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/89.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/89.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/94.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/94.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/97.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/97.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
	
	<h3>New Constuction Homes</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal8" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/60.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/60.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/61.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/61.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/62.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/62.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/66.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/66.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/67.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/67.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/69.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/69.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/70.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/70.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/77.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/77.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/99.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/99.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
	
	<h3>Outdoor Living Spaces</h3>
    
	<!-- id="category" [this is changeable this corresponds to the document ready script of the javascript]-->
	 <div id="cat_gal9" class="container" style="margin:0 auto;">
		
		<ul class="content gallery">
		 
			
			<li><a href="images/gallery/58.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/58.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/74.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/74.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/79.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/79.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/85.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/85.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/88.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/88.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/92.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/92.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/95.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/95.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/100.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/100.jpg"/></a>
			
			</li>

						 
			
			<li><a href="images/gallery/101.jpg" rel="gallery"><img alt="&nbsp;" src="images/gallery/tm/101.jpg"/></a>
			
			</li>

					
		</ul>	
        
		<br class="clear"/>
		<div class="page_navigation"></div>
	</div>
    <br class="clear"/>
    	
   
 </div>
	
	
    
        <div id="header">
    <ul>
    <li><a href="index.php" >Home<small></small></a></li>
    <li><a href="gallery.php"  class="active-menu">Gallery<small></small></a></li>
    <li><a href="services.php" >Services<small></small></a></li>
    <li><a href="about.php" >About Us<small></small></a></li>
    <li><a href="contact.php" >Contact<small></small></a></li>
    </ul>
    
    <div class="hd-left">
    <h6><small><a href="index.php"><img src="images/common/hd-logo.png" alt="" /></a></small>
    </h6>
        </div>
    </div>

  
    
        
    <br class="clear" />
    
</div>


		
    	
      <div id="ft-wrapper">
  <div id="footer">
  <div class="ft-left">
  <h6><big>Call Us (512) 452-4121</big>
  7801 N Lamar Suite C-47 Austin, TX 78752</h6>
  </div>
  
  <div class="ft-right">
  <p>Legal | Privacy Statement | Anti-Spam Policy | Terms &amp; Conditions</p>
  <p>Copyright &copy; 2013.Emerald Sunrooms. All Rights Reserved</p>
  <h5><img src="images/common/header_loglo.png" alt="" /> <span><a href="https://silverconnectwebdesign.com/website-development" rel="external">Web Design</a> Done by <a href="https://silverconnectwebdesign.com" rel="external">Silver Connect Web Design LLC</a></span></h5>
  </div>
  <br class="clear" />
  </div>
  </div>
<!--- END FOOTER -->
<noscript>
  <p class="nojavascript">Your browser does not support JavaScript. Please change your browser settings to enable Javascript.</p>
  </noscript>  
</body>
</html>