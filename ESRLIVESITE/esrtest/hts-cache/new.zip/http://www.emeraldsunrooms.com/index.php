
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Emerald Sunrooms | Sunrooms In Austin Texas</title>

	<meta http-equiv="Content-Language" content="en-us" />

	<link rel="SHORTCUT ICON" href="favicon.ico" type="image/x-icon" />

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

    <meta name="Description" content="Emerald Sunrooms offers quality and professional home improvement services in the Austin, TX area. From building sunrooms to new construction services, we guarantee to provide energy-saving and affordable solutions for your home remodeling needs." /> 

    <meta name="Keywords" content="emerald sunrooms, sunrooms in austin texas, remodeling service austin texas, new construction austin texas, solar screens austin texas, home renovations austin texas, home remodeling austin texas, outdoor living austin texas, solarium austin texas, screen rooms austin texas" /> 

	<link href="styles/styles.css" rel="stylesheet" type="text/css" />

    <link href="styles/contact.css" rel="stylesheet" type="text/css" />

    <script type="text/javascript" src="scripts/jquery.js"></script>

    

	<script type="text/javascript" src="scripts/gen_validatorv31.js"></script>

    <script type="text/javascript" src="scripts/cufon-yui.js"></script>

	<script type="text/javascript" src="scripts/arial_400-arial_700-arial_italic_400-arial_italic_700.font.js"></script>

    <script type="text/javascript" src="scripts/javascripts.js"></script>

    

    <link rel="stylesheet" type="text/css" href="styles/gallery.css" media="screen" />

    

    
    

    

	 
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50254533-1', 'emeraldsunrooms.com');
  ga('send', 'pageview');

</script>
    </head>

<body onload="blankTargetFix();" >



<div id="cn-wrapper">
<div id="main" class="clearfix">
	<div id="content">
    <h1>Emerald Sunrooms has completed almost 5,000 home improvement projects around this great State of ours and their still counting.</h1>
    <br />
    <br />
    <p>For over 15 years Emerald Sunrooms has been adding exceptional value to Central Texas Homes and making Homeowner's Dreams a Reality! When you combine Quality, Long-Term Community standing, a dedicated work force and 25 years in the construction industry you get one thing... Very Satisfied Customers!</p>
    </div>
    
        <div id="header">
    <ul>
    <li><a href="index.php"  class="active-menu">Home<small></small></a></li>
    <li><a href="gallery.php" >Gallery<small></small></a></li>
    <li><a href="services.php" >Services<small></small></a></li>
    <li><a href="about.php" >About Us<small></small></a></li>
    <li><a href="contact.php" >Contact<small></small></a></li>
    </ul>
    
    <div class="hd-left">
    <h6><small><a href="index.php"><img src="images/common/hd-logo.png" alt="" /></a></small>
        <big>Call (512) 452-4121</big>
    7801 N Lamar Suite C-47 Austin, TX 78752
    </h6>
        <h5><small><img src="images/common/hd-big.png" alt="" /></small>
    RECOGNIZED AS <span>ONE</span> OF TOP 
	50 <span>BEST REMODELERS</span> IN US</h5>
        </div>
    </div>

  
    
    	<div id="banner">
    <dl>
    <dt><small><img src="images/common/bn-dt1.png" alt="" /></small>
    REMODELING & NEW CONSTRUCTION</dt>
    <dd>Emerald Sunrooms and Design, Inc. has almost 30 years experience in remodeling, custom home building/renovation as well as general contracting for complete residential remodeling. Not only do we have almost 30 years of knowledgeable experience in the construction industry, we also have an A+ rating with BBB and the most satisfied customer ratings in Austin and surrounding.
    </small></dd>
    </dl>
    
    <dl>
    <dt><small><img src="images/common/bn-dt2.png" alt="" /></small>
    SOLAR SCREENS AND SUNROOMS</dt>
    <dd>Authorized dealer for Stoett Industries and SWSunControl retractable solar/insect screens.<br /><br />
		Click on "services" to see complete videos of our solar screens. 
    </dl>
    
    <dl>
    <dt><small><img src="images/common/bn-dt3.png" alt="" /></small>
    OUTDOOR LIVING</dt>
    <dd>Emerald Sunrooms and Design, Inc. has designed and constructed hundreds of outdoor living spaces.<br /><br />
		Converting existing patios and decks into living spaces as well as pouring engineered foundations for new construction of additions for extended living space outdoors, whether enclosed or open air with a fireplace to enjoy.
    </dd>
    </dl>
    <br class="clear" />
    </div>    
    <br class="clear" />
    
</div>
</div>

		<div id="cn-bot-wrapper">

	<div id="content-bottom">

    <div class="cn-bot-left">

    <h6>The <big>ORIGINAL</big> Sunroom &amp;<br />

    <big>Remodeling Company</big> of Austin</h6>

	<br />

	

    </div>

    

    <div class="cn-bot-right">

    <h6><a target="_blank" title="Emerald Sunrooms & Design Inc BBB Business Review" href="http://www.bbb.org/central-texas/business-reviews/construction-and-remodeling-services/emerald-sunrooms-design-inc-in-austin-tx-41957/#bbbonlineclick"><img alt="Emerald Sunrooms & Design Inc BBB Business Review" style="border: 0;" src="http://seal-austin.bbb.org//seals/blue-seal-293-61-emerald-sunrooms-design-inc-41957.png" /></a>
</h6>

    </div>

    <br class="clear" />

	<p class="logos">

		<a target="_blank" href="http://www.angieslist.com/companylist/us/tx/austin/emerald-sunrooms-reviews-2079142.htm"><img src="images/content/1.png" alt="" /></a>

		<a target="_blank" title="Emerald Sunrooms & Design Inc BBB Business Review" href="http://www.bbb.org/central-texas/business-reviews/construction-and-remodeling-services/emerald-sunrooms-design-inc-in-austin-tx-41957/#bbbonlineclick"><img alt="Emerald Sunrooms & Design Inc BBB Business Review" style="border: 0;" src="http://seal-austin.bbb.org//seals/blue-seal-120-61-emerald-sunrooms-design-inc-41957.png" /></a>


		<a target="_blank" href="http://www.guildquality.com/EmeraldSunrooms"><img src="images/content/3.png" alt="" /></a>

		<a target="_blank" href="http://www.yelp.com/biz/emerald-custom-homes-austin"><img src="images/content/4.png" alt="" /></a>

		<a target="_blank" href="http://www.houzz.com/pro/stacycummings/emerald-sunrooms-design-inc"><img src="images/content/5.png" alt="" /></a>

		<a target="_blank" href=""><img src="images/content/6.png" alt="" /></a>

		<a target="_blank" href=""><img src="images/content/7.png" alt="" style="padding:0 0 0 29px"/></a>

	</p>

    </div>

    </div>	
    	<div id="mn-wrapper">
    <div id="main-bottom">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    
    <div class="mn-divider-group">
    <div class="mn-divider">
    <h3>What <strong>They Say</strong>
    
    <h6>Click on GuildSurvey and Yelp logos to see what our customers have to say about us!</h6>
    </div>
    
    <div class="mn-divider">
    <h3>Doing <strong>What We Do Best!</strong></h3>	<h3><small style="font-size:11px;padding:0;line-height:100%;">From patio and pool enclosures to new home construction, we provide the highest quality workmanship as well as customer communication and satisfaction in the industry.</small></h3>
    <h3><small style="font-size:12px;padding:0;line-height:100%;">There are hundreds of agencies out there. How do you know which one is right for you?</small></h3>
    <h6 style="padding:0;"><big><img src="images/content/bottom/box-sign.png" alt="" /></big></h6>
    </div>
    
    <div class="mn-divider">
    <h3>Contact <strong>Us</strong>
    <small>Visit our office &amp; Meet Our Team</small></h3>
    <h5></h5>
    <h5></h5>
    <h5><small><img src="images/content/bottom/contact-img1.png" alt="" /></small> (+00) (512) 452-4121</h5>
    <h5><small><img src="images/content/bottom/contact-img2.png" alt="" /></small> <a href="mailto:esr0128@msn.com">esr0128@msn.com</a></h5>
    <h5><small><img src="images/content/bottom/contact-img3.png" alt="" /></small> 7801 N Lamar Suite C-47 Austin, TX 78752</h5>
    </div>
    <br class="clear" />
    </div>
    
    </div>
    </div>	
      <div id="ft-wrapper">
  <div id="footer">
  <div class="ft-left">
  <h6><big>Call Us (512) 452-4121</big>
  7801 N Lamar Suite C-47 Austin, TX 78752</h6>
  </div>
  
  <div class="ft-right">
  <p>Legal | Privacy Statement | Anti-Spam Policy | Terms &amp; Conditions</p>
  <p>Copyright &copy; 2013.Emerald Sunrooms. All Rights Reserved</p>
  <h5><img src="images/common/header_loglo.png" alt="" /> <span><a href="https://silverconnectwebdesign.com/website-development" rel="external">Web Design</a> Done by <a href="https://silverconnectwebdesign.com" rel="external">Silver Connect Web Design LLC</a></span></h5>
  </div>
  <br class="clear" />
  </div>
  </div>
<!--- END FOOTER -->
<noscript>
  <p class="nojavascript">Your browser does not support JavaScript. Please change your browser settings to enable Javascript.</p>
  </noscript>  
</body>
</html>